# 🤖 Telegram Points Bot – README

An interactive Telegram bot that features a gamified user experience with a points system, level progression, daily rewards, virtual inventory, store, VIP system, and leaderboard.

---

## 📌 Features

- 🎰 **Daily Spin** – Spin every 4 hours to earn coins and XP.
- 👤 **User Profile** – View your level, XP, coins, VIP status, and more.
- 🎒 **Inventory System** – See your items and sell them for coins or real money.
- 🛍️ **Coins Store** – Buy special items using your in-game coins.
- 🏆 **Leaderboard** – Top users sorted by level and coin count.
- 🎟️ **VIP System** – Become a VIP to unlock exclusive features (coming soon).
- 🤝 **Referral System** – Refer friends to earn bonuses (coming soon).

---

## 🚀 How to Run the Bot

### 1. Requirements

Make sure you have **Python 3.7+** installed.

Install required libraries:

```bash
pip install pyTelegramBotAPI
```

### 2. Set Your Bot Token

Open the script and set your bot token from [BotFather](https://t.me/BotFather):

```python
TOKEN = "YOUR_BOT_TOKEN_HERE"
```

### 3. Run the Bot

Simply run the bot using:

```bash
python bot.py
```

### 4. Data Storage

User data is automatically saved in a file named `users.json`.

---

## 📁 Project Structure

| File         | Description                          |
|--------------|--------------------------------------|
| `bot.py`     | Main Python script for the Telegram bot |
| `users.json` | Auto-generated user data storage     |

---

## ⚠️ Security Note

> **Do not share your bot token publicly!**  
> Anyone with access to your token can take control of your bot.

---

## 💡 Want to Improve It?

Feel free to expand the bot with features like:
- Translations
- Mini-games
- Quests
- Admin panel
- Real crypto integration
- In-app purchases
